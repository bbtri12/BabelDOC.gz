YADT Spec
===

## YADT Document Intermediate Language

[il_version_1.rnc](https://github.com/funstory-ai/yadt/blob/main/yadt/document_il/il_version_1.rnc): The definition of the intermediate language used between PDF parsing and rendering stages.

For other implementation details, please refer to [Implementation Details](ImplementationDetails/README.md).